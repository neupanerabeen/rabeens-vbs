import React from 'react';
import { Text } from 'react-native';


export const CreateRequest = props =>{

    return <Text>Create Request</Text>
}