export const APP_CONFIG = {
    "api_path":"http://192.168.1.16:8000",
    "token_store_key":"rabeens_token_key"
}